# TaskFlow - To-Do List Application

A full-stack to-do list application built with HTML, CSS, JavaScript (frontend) and PHP with MySQL (backend).

## Project Structure

```
/
├── database/
│   └── schema.sql          # MySQL database schema
├── backend/
│   ├── config/
│   │   └── database.php    # Database connection configuration
│   └── api/
│       ├── register.php    # User registration endpoint
│       ├── login.php       # User login endpoint
│       ├── logout.php      # User logout endpoint
│       ├── check_auth.php  # Authentication check endpoint
│       └── tasks/
│           ├── create.php  # Create task endpoint
│           ├── read.php    # Read tasks endpoint
│           ├── update.php  # Update task endpoint
│           └── delete.php  # Delete task endpoint
└── frontend/
    ├── index.html          # Login page
    ├── register.html       # Registration page
    ├── dashboard.html      # Main dashboard
    └── assets/
        ├── css/
        │   └── styles.css  # Application styles
        └── js/
            ├── config.js   # Configuration
            ├── utils.js    # Utility functions
            ├── auth.js     # Authentication logic
            └── tasks.js    # Task management logic
```

## Setup Instructions

### Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx) or XAMPP/WAMP/MAMP

### Installation

1. **Set up the database:**
   - Open MySQL command line or phpMyAdmin
   - Run the SQL commands in `database/schema.sql`

2. **Configure database connection:**
   - Open `backend/config/database.php`
   - Update the following values to match your setup:
     ```php
     private $host = "localhost";
     private $db_name = "todo_app";
     private $username = "root";
     private $password = "";
     ```

3. **Deploy to web server:**
   - Copy all files to your web server directory
   - For XAMPP: `C:/xampp/htdocs/todo-app/`
   - For WAMP: `C:/wamp/www/todo-app/`

4. **Update API URL (if needed):**
   - Open `frontend/assets/js/config.js`
   - Update `API_BASE_URL` to match your server path

5. **Access the application:**
   - Open your browser and navigate to:
   - `http://localhost/todo-app/frontend/index.html`

## Features

- **User Authentication**
  - Secure registration with password hashing
  - Login/Logout functionality
  - Session-based authentication

- **Task Management (CRUD)**
  - Create tasks with title, description, due date, and priority
  - View all tasks in a responsive dashboard
  - Edit task details
  - Mark tasks as complete/incomplete
  - Delete tasks

- **Filtering & Search**
  - Filter by status (completed/incomplete)
  - Filter by priority (low/medium/high)
  - Search tasks by title

- **Responsive Design**
  - Mobile-friendly interface
  - Clean, modern UI
  - Priority color coding (green/orange/red)

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/register.php` | POST | Register new user |
| `/login.php` | POST | User login |
| `/logout.php` | POST | User logout |
| `/check_auth.php` | GET | Check auth status |
| `/tasks/create.php` | POST | Create new task |
| `/tasks/read.php` | GET | Get all tasks |
| `/tasks/update.php` | PUT | Update task |
| `/tasks/delete.php` | DELETE | Delete task |

## Security Features

- Password hashing with `password_hash()`
- PDO prepared statements to prevent SQL injection
- Input sanitization
- CORS headers for API security
- Session-based authentication
