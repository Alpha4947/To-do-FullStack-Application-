<?php
/**
 * Check Authentication Status API
 * GET: Verify if user is logged in
 */

session_start();
include_once '../config/auth.php';


header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$userId = get_authenticated_user_id();

if (!empty($userId)) {
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "authenticated" => true,
        "user" => [
            "id" => $userId,
            "name" => $_SESSION['user_name'] ?? '',
            "email" => $_SESSION['user_email'] ?? ''
        ]
    ]);
} else {
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "authenticated" => false
    ]);
}
?>
