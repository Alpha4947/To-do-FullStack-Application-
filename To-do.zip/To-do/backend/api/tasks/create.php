<?php
/**
 * Create Task API
 * POST: Create a new task for authenticated user
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include_once '../../config/database.php';
include_once '../../config/auth.php';

// Check authentication
$userId = get_authenticated_user_id();
if (empty($userId)) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Unauthorized. Please login."]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Method not allowed"]);
    exit();
}

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Validate required fields
if (empty($data->title)) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Task title is required"]);
    exit();
}

// Validate priority
$validPriorities = ['low', 'medium', 'high'];
$priority = isset($data->priority) && in_array(strtolower($data->priority), $validPriorities) 
    ? strtolower($data->priority) 
    : 'medium';

$database = new Database();
$db = $database->getConnection();

if ($db === null) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit();
}

try {
    $query = "INSERT INTO tasks (user_id, title, description, due_date, priority, status) 
              VALUES (:user_id, :title, :description, :due_date, :priority, 'incomplete')";
    
    $stmt = $db->prepare($query);

    $title = htmlspecialchars(strip_tags($data->title));
    $description = isset($data->description) ? htmlspecialchars(strip_tags($data->description)) : null;
    $dueDate = isset($data->due_date) && !empty($data->due_date) ? $data->due_date : null;

    $stmt->bindParam(":user_id", $userId);
    $stmt->bindParam(":title", $title);
    $stmt->bindParam(":description", $description);
    $stmt->bindParam(":due_date", $dueDate);
    $stmt->bindParam(":priority", $priority);

    if ($stmt->execute()) {
        $taskId = $db->lastInsertId();
        
        // Fetch the created task
        $fetchQuery = "SELECT * FROM tasks WHERE id = :id";
        $fetchStmt = $db->prepare($fetchQuery);
        $fetchStmt->bindParam(":id", $taskId);
        $fetchStmt->execute();
        $task = $fetchStmt->fetch();

        http_response_code(201);
        echo json_encode([
            "success" => true,
            "message" => "Task created successfully",
            "task" => $task
        ]);
    } else {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Unable to create task"]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Failed to create task: " . $e->getMessage()]);
}
?>
