<?php
/**
 * Delete Task API
 * DELETE: Remove a task for authenticated user
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include_once '../../config/database.php';
include_once '../../config/auth.php';

// Check authentication
$userId = get_authenticated_user_id();
if (empty($userId)) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Unauthorized. Please login."]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Method not allowed"]);
    exit();
}

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Validate task ID
if (empty($data->id)) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Task ID is required"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();

if ($db === null) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit();
}

try {
    $taskId = $data->id;

    // Verify task belongs to user and delete
    $query = "DELETE FROM tasks WHERE id = :id AND user_id = :user_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(":id", $taskId);
    $stmt->bindParam(":user_id", $userId);

    if ($stmt->execute()) {
        if ($stmt->rowCount() > 0) {
            http_response_code(200);
            echo json_encode([
                "success" => true,
                "message" => "Task deleted successfully"
            ]);
        } else {
            http_response_code(404);
            echo json_encode(["success" => false, "message" => "Task not found"]);
        }
    } else {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Unable to delete task"]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Failed to delete task: " . $e->getMessage()]);
}
?>
