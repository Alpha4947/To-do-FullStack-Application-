<?php
/**
 * Read Tasks API
 * GET: Retrieve all tasks for authenticated user with optional filtering
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include_once '../../config/database.php';
include_once '../../config/auth.php';

// Check authentication
$userId = get_authenticated_user_id();
if (empty($userId)) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Unauthorized. Please login."]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Method not allowed"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();

if ($db === null) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit();
}

try {
    // Base query
    $query = "SELECT * FROM tasks WHERE user_id = :user_id";
    $params = [":user_id" => $userId];

    // Apply status filter
    if (isset($_GET['status']) && in_array($_GET['status'], ['completed', 'incomplete'])) {
        $query .= " AND status = :status";
        $params[":status"] = $_GET['status'];
    }

    // Apply priority filter
    if (isset($_GET['priority']) && in_array(strtolower($_GET['priority']), ['low', 'medium', 'high'])) {
        $query .= " AND priority = :priority";
        $params[":priority"] = strtolower($_GET['priority']);
    }

    // Apply search filter
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $query .= " AND (title LIKE :search OR description LIKE :search)";
        $params[":search"] = "%" . $_GET['search'] . "%";
    }

    // Order by created date (newest first)
    $query .= " ORDER BY created_at DESC";

    $stmt = $db->prepare($query);
    
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }

    $stmt->execute();
    $tasks = $stmt->fetchAll();

    http_response_code(200);
    echo json_encode([
        "success" => true,
        "count" => count($tasks),
        "tasks" => $tasks
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Failed to fetch tasks: " . $e->getMessage()]);
}
?>
