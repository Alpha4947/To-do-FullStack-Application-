<?php
/**
 * Update Task API
 * PUT/PATCH: Update an existing task for authenticated user
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT, PATCH, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

include_once '../../config/database.php';
include_once '../../config/auth.php';

// Check authentication
$userId = get_authenticated_user_id();
if (empty($userId)) {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Unauthorized. Please login."]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'PUT' && $_SERVER['REQUEST_METHOD'] !== 'PATCH') {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Method not allowed"]);
    exit();
}

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Validate task ID
if (empty($data->id)) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Task ID is required"]);
    exit();
}

$database = new Database();
$db = $database->getConnection();

if ($db === null) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit();
}

try {
    $taskId = $data->id;

    // Verify task belongs to user
    $checkQuery = "SELECT id FROM tasks WHERE id = :id AND user_id = :user_id";
    $checkStmt = $db->prepare($checkQuery);
    $checkStmt->bindParam(":id", $taskId);
    $checkStmt->bindParam(":user_id", $userId);
    $checkStmt->execute();

    if ($checkStmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(["success" => false, "message" => "Task not found"]);
        exit();
    }

    // Build update query dynamically
    $updateFields = [];
    $params = [":id" => $taskId, ":user_id" => $userId];

    if (isset($data->title) && !empty($data->title)) {
        $updateFields[] = "title = :title";
        $params[":title"] = htmlspecialchars(strip_tags($data->title));
    }

    if (isset($data->description)) {
        $updateFields[] = "description = :description";
        $params[":description"] = htmlspecialchars(strip_tags($data->description));
    }

    if (isset($data->due_date)) {
        $updateFields[] = "due_date = :due_date";
        $params[":due_date"] = !empty($data->due_date) ? $data->due_date : null;
    }

    if (isset($data->priority) && in_array(strtolower($data->priority), ['low', 'medium', 'high'])) {
        $updateFields[] = "priority = :priority";
        $params[":priority"] = strtolower($data->priority);
    }

    if (isset($data->status) && in_array($data->status, ['completed', 'incomplete'])) {
        $updateFields[] = "status = :status";
        $params[":status"] = $data->status;
    }

    if (empty($updateFields)) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "No fields to update"]);
        exit();
    }

    $query = "UPDATE tasks SET " . implode(", ", $updateFields) . " WHERE id = :id AND user_id = :user_id";
    $stmt = $db->prepare($query);

    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }

    if ($stmt->execute()) {
        // Fetch updated task
        $fetchQuery = "SELECT * FROM tasks WHERE id = :id";
        $fetchStmt = $db->prepare($fetchQuery);
        $fetchStmt->bindParam(":id", $taskId);
        $fetchStmt->execute();
        $task = $fetchStmt->fetch();

        http_response_code(200);
        echo json_encode([
            "success" => true,
            "message" => "Task updated successfully",
            "task" => $task
        ]);
    } else {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Unable to update task"]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Failed to update task: " . $e->getMessage()]);
}
?>
