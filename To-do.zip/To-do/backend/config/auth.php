<?php
/**
 * Stateless token helpers for API authentication.
 */

if (!defined('AUTH_SECRET')) {
    // Replace this in production with an environment secret.
    define('AUTH_SECRET', 'todo_app_change_this_secret_key');
}

function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64url_decode($data) {
    $remainder = strlen($data) % 4;
    if ($remainder) {
        $data .= str_repeat('=', 4 - $remainder);
    }
    return base64_decode(strtr($data, '-_', '+/'));
}

function issue_auth_token($userId) {
    $payload = json_encode([
        'uid' => (int) $userId,
        'exp' => time() + (7 * 24 * 60 * 60)
    ]);

    $payloadEncoded = base64url_encode($payload);
    $signature = hash_hmac('sha256', $payloadEncoded, AUTH_SECRET, true);

    return $payloadEncoded . '.' . base64url_encode($signature);
}

function verify_auth_token($token) {
    if (empty($token) || strpos($token, '.') === false) {
        return null;
    }

    [$payloadEncoded, $signatureEncoded] = explode('.', $token, 2);
    $expectedSignature = hash_hmac('sha256', $payloadEncoded, AUTH_SECRET, true);
    $providedSignature = base64url_decode($signatureEncoded);

    if ($providedSignature === false || !hash_equals($expectedSignature, $providedSignature)) {
        return null;
    }

    $payloadRaw = base64url_decode($payloadEncoded);
    if ($payloadRaw === false) {
        return null;
    }

    $payload = json_decode($payloadRaw, true);
    if (!is_array($payload) || empty($payload['uid']) || empty($payload['exp'])) {
        return null;
    }

    if ((int) $payload['exp'] < time()) {
        return null;
    }

    return (int) $payload['uid'];
}

function get_bearer_token() {
    $possibleHeaders = [];

    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        $possibleHeaders[] = $_SERVER['HTTP_AUTHORIZATION'];
    }
    if (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $possibleHeaders[] = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    }

    if (function_exists('getallheaders')) {
        $headers = getallheaders();
        if (is_array($headers)) {
            foreach ($headers as $name => $value) {
                if (strcasecmp($name, 'Authorization') === 0 && !empty($value)) {
                    $possibleHeaders[] = $value;
                }
            }
        }
    }

    foreach ($possibleHeaders as $authHeader) {
        if (preg_match('/Bearer\s+(.+)$/i', $authHeader, $matches)) {
            return trim($matches[1]);
        }
    }

    return null;
}

function get_authenticated_user_id() {
    if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true && !empty($_SESSION['user_id'])) {
        return (int) $_SESSION['user_id'];
    }

    $token = get_bearer_token();
    return verify_auth_token($token);
}
?>
