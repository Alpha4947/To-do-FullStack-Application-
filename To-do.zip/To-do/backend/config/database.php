<?php
/**
 * Backward-compatible database config entrypoint.
 * Existing API files include this path.
 */

include_once __DIR__ . '/todo_app.php';

?>
