/**
 * Authentication Module
 * Handles login and registration
 */

document.addEventListener('DOMContentLoaded', () => {
    // Check if user is already logged in
    if (isAuthenticated()) {
        redirectTo('dashboard.html');
        return;
    }

    // Initialize forms
    initLoginForm();
    initRegisterForm();
});

/**
 * Initialize login form
 */
function initLoginForm() {
    const form = document.getElementById('login-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        clearAlert('alert-container');

        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;
        const submitBtn = document.getElementById('login-btn');

        // Validate inputs
        if (!email || !password) {
            showAlert('alert-container', 'Please fill in all fields');
            return;
        }

        setButtonLoading(submitBtn, true);

        try {
            const response = await apiRequest('login.php', {
                method: 'POST',
                body: JSON.stringify({ email, password })
            });

            if (response.ok && response.data.success) {
                // Save user session
                saveUserSession(response.data.user, response.data.token);
                showToast('Login successful! Redirecting...');
                
                // Redirect to dashboard
                setTimeout(() => {
                    redirectTo('dashboard.html');
                }, 500);
            } else {
                showAlert('alert-container', response.data.message || 'Login failed');
            }
        } catch (error) {
            console.error('Login error:', error);
            showAlert('alert-container', 'An error occurred. Please try again.');
        } finally {
            setButtonLoading(submitBtn, false);
        }
    });
}

/**
 * Initialize registration form
 */
function initRegisterForm() {
    const form = document.getElementById('register-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        clearAlert('alert-container');

        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm-password').value;
        const submitBtn = document.getElementById('register-btn');

        // Validate inputs
        if (!name || !email || !password || !confirmPassword) {
            showAlert('alert-container', 'Please fill in all fields');
            return;
        }

        if (password.length < 6) {
            showAlert('alert-container', 'Password must be at least 6 characters');
            return;
        }

        if (password !== confirmPassword) {
            showAlert('alert-container', 'Passwords do not match');
            return;
        }

        setButtonLoading(submitBtn, true);

        try {
            const response = await apiRequest('register.php', {
                method: 'POST',
                body: JSON.stringify({ name, email, password })
            });

            if (response.ok && response.data.success) {
                showAlert('alert-container', 'Registration successful! Redirecting...', 'success');

                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1200);
            } else {
                showAlert(
                    'alert-container',
                    response.data?.message || 'Registration failed'
                );
            }
        } catch (error) {
            console.error('REGISTER ERROR:', error);
            showAlert('alert-container', 'Network error. Please try again.');
        } finally {
            setButtonLoading(submitBtn, false);
        }
    });
}
