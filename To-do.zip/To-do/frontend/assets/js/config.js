/**
 * Application Configuration
 * Update API_BASE_URL to match your server setup
 */

const CONFIG = {
    API_BASE_URL: 'http://localhost/To-do/backend/api/',
    
    // Session storage keys
    STORAGE_KEYS: {
        USER: 'todo_user',
        TOKEN: 'todo_token'
    },
    
    // Debounce delay for search (in milliseconds)
    SEARCH_DEBOUNCE: 300,
    
    // Toast notification duration (in milliseconds)
    TOAST_DURATION: 3000
};

// Freeze config to prevent modifications
Object.freeze(CONFIG);
Object.freeze(CONFIG.STORAGE_KEYS);
