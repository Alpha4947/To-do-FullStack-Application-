/**
 * Tasks Module
 * Handles task CRUD operations and dashboard functionality
 */

// Global state
let allTasks = []; // full list from backend
let tasks = [];    // currently filtered list
let isSavingTask = false;
let currentFilters = {
    status: '',
    priority: '',
    search: ''
};

document.addEventListener('DOMContentLoaded', () => {
    // Check authentication
    if (!isAuthenticated()) {
        redirectTo('index.html');
        return;
    }

    // Initialize dashboard
    initDashboard();
});

/**
 * Initialize dashboard
 */
function initDashboard() {
    // Display user name
    const user = getUserSession();
    if (user) {
        document.getElementById('user-name').textContent = user.name;
    }

    // Initialize event listeners
    initLogout();
    initTaskModal();
    initDeleteModal();
    initFilters();

    // Load tasks
    loadTasks();
}

/**
 * Initialize logout functionality
 */
function initLogout() {
    document.getElementById('logout-btn').addEventListener('click', async () => {
        try {
            await apiRequest('logout.php', { method: 'POST' });
        } catch (error) {
            console.error('Logout error:', error);
        }
        
        clearUserSession();
        showToast('Logged out successfully');
        redirectTo('index.html');
    });
}

/**
 * Initialize task modal
 */
function initTaskModal() {
    const modal = document.getElementById('task-modal');
    const addBtn = document.getElementById('add-task-btn');
    const closeBtn = document.getElementById('modal-close');
    const cancelBtn = document.getElementById('modal-cancel');
    const saveBtn = document.getElementById('modal-save');
    const form = document.getElementById('task-form');

    // Open modal for new task
    addBtn.addEventListener('click', () => {
        openTaskModal();
    });

    // Close modal
    closeBtn.addEventListener('click', closeTaskModal);
    cancelBtn.addEventListener('click', closeTaskModal);

    // Close on overlay click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeTaskModal();
        }
    });

    // Save task
    saveBtn.addEventListener('click', async () => {
        await saveTask();
    });

    // Handle form submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        await saveTask();
    });
}

/**
 * Open task modal
 * @param {Object} task - Task data for editing (optional)
 */
function openTaskModal(task = null) {
    const modal = document.getElementById('task-modal');
    const title = document.getElementById('modal-title');
    const taskId = document.getElementById('task-id');
    const taskTitle = document.getElementById('task-title');
    const taskDescription = document.getElementById('task-description');
    const taskDueDate = document.getElementById('task-due-date');
    const taskPriority = document.getElementById('task-priority');

    if (task) {
        // Edit mode
        title.textContent = 'Edit Task';
        taskId.value = task.id;
        taskTitle.value = task.title;
        taskDescription.value = task.description || '';
        taskDueDate.value = formatDateForInput(task.due_date);
        taskPriority.value = task.priority;
    } else {
        // Add mode
        title.textContent = 'Add New Task';
        taskId.value = '';
        taskTitle.value = '';
        taskDescription.value = '';
        taskDueDate.value = '';
        taskPriority.value = 'medium';
    }

    modal.classList.add('active');
    taskTitle.focus();
}

/**
 * Close task modal
 */
function closeTaskModal() {
    const modal = document.getElementById('task-modal');
    modal.classList.remove('active');
}

/**
 * Save task (create or update)
 */
async function saveTask() {
    if (isSavingTask) return; // Prevent duplicate submit (button inside form).
    isSavingTask = true;
    const saveBtn = document.getElementById('modal-save');
    const taskId = document.getElementById('task-id').value;
    const taskTitle = document.getElementById('task-title').value.trim();
    const taskDescription = document.getElementById('task-description').value.trim();
    const taskDueDate = document.getElementById('task-due-date').value;
    const taskPriority = document.getElementById('task-priority').value;

    // Validate
    if (!taskTitle) {
        showToast('Please enter a task title', 'error');
        return;
    }

    setButtonLoading(saveBtn, true);

    const taskData = {
        title: taskTitle,
        description: taskDescription,
        due_date: taskDueDate || null,
        priority: taskPriority
    };

    try {
        let response;
        
        if (taskId) {
            // Update existing task
            taskData.id = parseInt(taskId);
            response = await apiRequest('tasks/update.php', {
                method: 'PUT',
                body: JSON.stringify(taskData)
            });
        } else {
            // Create new task
            response = await apiRequest('tasks/create.php', {
                method: 'POST',
                body: JSON.stringify(taskData)
            });
        }

        if (response.ok && response.data.success) {
            if (response.data.task) {
                if (taskId) {
                    // Update in allTasks
                    const allIndex = allTasks.findIndex(task => String(task.id) === String(response.data.task.id));
                    if (allIndex !== -1) {
                        allTasks[allIndex] = response.data.task;
                    }
                } else {
                    // New task: add to beginning of allTasks
                    allTasks.unshift(response.data.task);
                }

                // Re-apply filters to update visible list
                applyFiltersAndRender();
            }

            showToast(taskId ? 'Task updated successfully' : 'Task created successfully');
            closeTaskModal();
        } else {
            showToast(response.data.message || 'Failed to save task', 'error');
        }
    } catch (error) {
        console.error('Save task error:', error);
        showToast('An error occurred. Please try again.', 'error');
    } finally {
        setButtonLoading(saveBtn, false);
        isSavingTask = false;
    }
}

/**
 * Initialize delete modal
 */
function initDeleteModal() {
    const modal = document.getElementById('delete-modal');
    const closeBtn = document.getElementById('delete-modal-close');
    const cancelBtn = document.getElementById('delete-cancel');
    const confirmBtn = document.getElementById('delete-confirm');

    closeBtn.addEventListener('click', closeDeleteModal);
    cancelBtn.addEventListener('click', closeDeleteModal);

    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeDeleteModal();
        }
    });

    confirmBtn.addEventListener('click', async () => {
        await deleteTask();
    });
}

/**
 * Open delete confirmation modal
 * @param {number} taskId - Task ID to delete
 */
function openDeleteModal(taskId) {
    const modal = document.getElementById('delete-modal');
    document.getElementById('delete-task-id').value = taskId;
    modal.classList.add('active');
}

/**
 * Close delete modal
 */
function closeDeleteModal() {
    const modal = document.getElementById('delete-modal');
    modal.classList.remove('active');
}

/**
 * Delete task
 */
async function deleteTask() {
    const confirmBtn = document.getElementById('delete-confirm');
    const taskId = document.getElementById('delete-task-id').value;

    setButtonLoading(confirmBtn, true);

    try {
        const response = await apiRequest('tasks/delete.php', {
            method: 'DELETE',
            body: JSON.stringify({ id: parseInt(taskId) })
        });

        if (response.ok && response.data.success) {
            // Remove from allTasks and re-apply filters
            allTasks = allTasks.filter(task => String(task.id) !== String(taskId));
            applyFiltersAndRender();

            showToast('Task deleted successfully');
            closeDeleteModal();
        } else {
            showToast(response.data.message || 'Failed to delete task', 'error');
        }
    } catch (error) {
        console.error('Delete task error:', error);
        showToast('An error occurred. Please try again.', 'error');
    } finally {
        setButtonLoading(confirmBtn, false);
    }
}

/**
 * Initialize filters
 */
function initFilters() {
    const statusFilter = document.getElementById('status-filter');
    const priorityFilter = document.getElementById('priority-filter');
    const searchInput = document.getElementById('search-input');

    statusFilter.addEventListener('change', (e) => {
        currentFilters.status = e.target.value;
        applyFiltersAndRender();
    });

    priorityFilter.addEventListener('change', (e) => {
        currentFilters.priority = e.target.value;
        applyFiltersAndRender();
    });

    // Debounced search
    const debouncedSearch = debounce((value) => {
        currentFilters.search = value;
        applyFiltersAndRender();
    }, CONFIG.SEARCH_DEBOUNCE);

    searchInput.addEventListener('input', (e) => {
        debouncedSearch(e.target.value.trim());
    });
}

/**
 * Load tasks from API and store full list in allTasks.
 * Filtering/search is done purely on the frontend.
 */
async function loadTasks(options = {}) {
    const taskList = document.getElementById('task-list');
    const loadingState = document.getElementById('loading-state');
    const { silent = false } = options;

    if (!silent) {
        taskList.innerHTML = '';
        taskList.appendChild(loadingState);
        loadingState.classList.remove('hidden');
    }

    try {
        const response = await apiRequest('tasks/read.php', { method: 'GET' });

        if (!response.ok || !response.data.success) {
            if (silent) return;
            taskList.innerHTML = `
                <div class="task-empty">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="15" y1="9" x2="9" y2="15"></line>
                        <line x1="9" y1="9" x2="15" y2="15"></line>
                    </svg>
                    <h3>Error loading tasks</h3>
                    <p>${response.data.message || 'Please try again later'}</p>
                </div>
            `;
            return;
        }

        allTasks = Array.isArray(response.data.tasks) ? response.data.tasks : [];
        applyFiltersAndRender();
    } catch (error) {
        console.error('Load tasks error:', error);
        if (silent) return;
        taskList.innerHTML = `
            <div class="task-empty">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="15" y1="9" x2="9" y2="15"></line>
                    <line x1="9" y1="9" x2="15" y2="15"></line>
                </svg>
                <h3>Error loading tasks</h3>
                <p>Please check your connection and try again</p>
            </div>
        `;
    }
}

/**
 * Apply current filters/search to allTasks and render/update stats.
 */
function applyFiltersAndRender() {
    const search = (currentFilters.search || '').toLowerCase();
    const statusFilter = currentFilters.status;
    const priorityFilter = currentFilters.priority;

    tasks = allTasks.filter(task => {
        const matchesStatus = !statusFilter || task.status === statusFilter;
        const matchesPriority = !priorityFilter || task.priority === priorityFilter;

        const title = (task.title || '').toLowerCase();
        const description = (task.description || '').toLowerCase();
        const matchesSearch = !search || title.includes(search) || description.includes(search);

        return matchesStatus && matchesPriority && matchesSearch;
    });

    renderTasks();
    updateStats();
}

/**
 * Render tasks in the list
 */
function renderTasks() {
    const taskList = document.getElementById('task-list');

    if (tasks.length === 0) {
        taskList.innerHTML = `
            <div class="task-empty">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M9 11l3 3L22 4"></path>
                    <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                </svg>
                <h3>No tasks found</h3>
                <p>Create your first task by clicking the "Add Task" button</p>
            </div>
        `;
        return;
    }

    taskList.innerHTML = tasks.map(task => createTaskCard(task)).join('');

    // Add event listeners to task cards
    attachTaskEventListeners();
}

/**
 * Create task card HTML
 * @param {Object} task - Task data
 * @returns {string} - HTML string
 */
function createTaskCard(task) {
    const isCompleted = task.status === 'completed';
    
    return `
        <div class="task-card ${isCompleted ? 'completed' : ''}" data-task-id="${task.id}">
            <div class="task-checkbox ${isCompleted ? 'checked' : ''}" data-action="toggle" data-task-id="${task.id}">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
            </div>
            <div class="task-content">
                <div class="task-header">
                    <h3 class="task-title">${escapeHtml(task.title)}</h3>
                    <span class="task-priority ${task.priority}">${task.priority}</span>
                </div>
                ${task.description ? `<p class="task-description">${escapeHtml(task.description)}</p>` : ''}
                <div class="task-meta">
                    ${task.due_date ? `
                        <span class="task-meta-item">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                <line x1="16" y1="2" x2="16" y2="6"></line>
                                <line x1="8" y1="2" x2="8" y2="6"></line>
                                <line x1="3" y1="10" x2="21" y2="10"></line>
                            </svg>
                            ${formatDate(task.due_date)}
                        </span>
                    ` : ''}
                    <span class="task-meta-item">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                        ${formatDate(task.created_at)}
                    </span>
                </div>
            </div>
            <div class="task-actions">
                <button class="btn btn-outline btn-sm btn-icon" data-action="edit" data-task-id="${task.id}" title="Edit">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                    </svg>
                </button>
                <button class="btn btn-danger btn-sm btn-icon" data-action="delete" data-task-id="${task.id}" title="Delete">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="3 6 5 6 21 6"></polyline>
                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                        <line x1="10" y1="11" x2="10" y2="17"></line>
                        <line x1="14" y1="11" x2="14" y2="17"></line>
                    </svg>
                </button>
            </div>
        </div>
    `;
}

/**
 * Attach event listeners to task cards
 */
function attachTaskEventListeners() {
    // Toggle completion
    document.querySelectorAll('[data-action="toggle"]').forEach(element => {
        element.addEventListener('click', async (e) => {
            const taskId = parseInt(e.currentTarget.dataset.taskId);
            await toggleTaskStatus(taskId);
        });
    });

    // Edit task
    document.querySelectorAll('[data-action="edit"]').forEach(element => {
        element.addEventListener('click', (e) => {
            const taskId = parseInt(e.currentTarget.dataset.taskId);
            const task = tasks.find(t => t.id == taskId);
            if (task) {
                openTaskModal(task);
            }
        });
    });

    // Delete task
    document.querySelectorAll('[data-action="delete"]').forEach(element => {
        element.addEventListener('click', (e) => {
            const taskId = parseInt(e.currentTarget.dataset.taskId);
            openDeleteModal(taskId);
        });
    });
}

/**
 * Toggle task completion status
 * @param {number} taskId - Task ID
 */
async function toggleTaskStatus(taskId) {
    const task = tasks.find(t => t.id == taskId);
    if (!task) return;

    const newStatus = task.status === 'completed' ? 'incomplete' : 'completed';

    try {
        const response = await apiRequest('tasks/update.php', {
            method: 'PUT',
            body: JSON.stringify({
                id: taskId,
                status: newStatus
            })
        });

        if (response.ok && response.data.success) {
            task.status = newStatus;

            // Also update in allTasks
            const allIndex = allTasks.findIndex(t => String(t.id) === String(taskId));
            if (allIndex !== -1) {
                allTasks[allIndex].status = newStatus;
            }

            applyFiltersAndRender();
            showToast(newStatus === 'completed' ? 'Task completed!' : 'Task marked as incomplete');
        } else {
            showToast(response.data.message || 'Failed to update task', 'error');
        }
    } catch (error) {
        console.error('Toggle status error:', error);
        showToast('An error occurred. Please try again.', 'error');
    }
}

/**
 * Update dashboard stats
 */
function updateStats() {
    const total = tasks.length;
    const completed = tasks.filter(t => t.status === 'completed').length;
    const pending = tasks.filter(t => t.status === 'incomplete').length;
    const highPriority = tasks.filter(t => t.priority === 'high' && t.status === 'incomplete').length;

    document.getElementById('total-tasks').textContent = total;
    document.getElementById('completed-tasks').textContent = completed;
    document.getElementById('pending-tasks').textContent = pending;
    document.getElementById('high-priority-tasks').textContent = highPriority;
}
